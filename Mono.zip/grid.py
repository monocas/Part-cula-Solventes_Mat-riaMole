from numpy import reshape, array, nditer
from random import shuffle, choice
import matplotlib.pyplot as plt

def plotGrid(ax, nrows=3, ncols=3):
    nrows *= 2
    ncols *= 2

    ax.plot([0, 0, ncols, ncols, 0], [0, nrows, nrows, 0, 0], linewidth=3, color='#000000')

    for n in range(1, int(nrows/2)):
        n *= 2
        ax.plot([0, ncols], [n, n], linewidth=3, color='#000000')

    for n in range(1, int(ncols/2)):
        n *= 2
        ax.plot([n, n], [0, nrows], linewidth=3, color='#000000')

def plotAtoms(ax, atomTypes, nrows=3, ncols=3):
    matrix = reshape(array([atomTypes]), (nrows, ncols))
    it = nditer(matrix, flags=['multi_index'])

    for value in it:
        x, y = it.multi_index
        ax.scatter(2*y+1, 2*x+1, color=colorCode[value])

def plotGridAndAtoms(ax, fracA, nrows=3, ncols=3):
    qnttA = int(fracA * nrows * ncols)
    qnttB = nrows * ncols - qnttA

    initial = [0 for _ in range(qnttA)] + [1 for _ in range(qnttB)]
    shuffle(initial)
    while (initial in permutatoinsUsed):
        shuffle(initial)
    
    permutatoinsUsed.append(initial)

    plotGrid(ax, nrows, ncols)
    plotAtoms(ax, initial, nrows, ncols)

def colorCodeGenerator(number):
    if number <= 2:
        return ['#9A32CD', '#00F5FF']

    colors = []
    for _ in range(number):
        a = [choice('0123456789ABCDEF') for _ in range(6)]
        colors.append('#' + ''.join(a))
    return colors

def generateRandomFig(frac, plotSize, figGrid):
    fig, axss = plt.subplots(figGrid[0], figGrid[1], figsize=(3*figGrid[0], 3*figGrid[1]), dpi=100)
    axs = array([axss[::-1]]).ravel()
    
    for ax in axs[:-1:]:
        ax.axis('off')
        plotGridAndAtoms(ax, frac, plotSize[0], plotSize[1])
    
    axs[-1].axis('off')

    axs[-1].scatter(.25, 1, color=colorCode[1], s=150)
    axs[-1].scatter(.25, 2, color=colorCode[0], s=150)
    
    axs[-1].annotate('Átomo B', [.25, 1], [.35, .9])
    axs[-1].annotate('Átomo A', [.25, 2], [.35, 1.9])

    axs[-1].set_xlim([0, 1])
    axs[-1].set_ylim([0, 3])
    
    fig.suptitle(f'Exemplos de permutação do sistema\nde 2 átomos com fração {frac:.0%}', y=.97, weight='bold', size='xx-large')
    fig.savefig('grid.png')

    plt.show()

permutatoinsUsed = []

figGrid = 3, 3
plotSize = 4, 4
# colorCode = colorCodeGenerator(2)
colorCode = ['#EEAD2D', '#9A32CD']
generateRandomFig(.5, plotSize, figGrid)
